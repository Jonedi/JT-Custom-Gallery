(function( $ ) {
	'use strict';

	/**
	 * Todo el código Javascript orientado a la administración
	 * debe estar escrito aquí
	 */
    
    $('.jtcg-container').jtcg();

})( jQuery );